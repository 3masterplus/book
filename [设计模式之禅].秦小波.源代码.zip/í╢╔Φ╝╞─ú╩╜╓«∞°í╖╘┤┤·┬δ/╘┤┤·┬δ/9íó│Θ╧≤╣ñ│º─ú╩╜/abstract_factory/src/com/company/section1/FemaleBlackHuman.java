package com.company.section1;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public class FemaleBlackHuman extends AbstractBlackHuman {

	//Ů�Ժ���
	public void getSex() {
		System.out.println("����Ů��");
	}

}
