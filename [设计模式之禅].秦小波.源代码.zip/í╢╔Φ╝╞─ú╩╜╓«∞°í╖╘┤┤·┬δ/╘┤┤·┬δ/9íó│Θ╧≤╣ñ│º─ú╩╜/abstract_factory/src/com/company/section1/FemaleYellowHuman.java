package com.company.section1;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public class FemaleYellowHuman extends AbstractYellowHuman {

	//����Ů��
	public void getSex() {
		System.out.println("����Ů��");
	}

}
