/**
 * 
 */
package com.company.section1;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * ����˶Ϻ󣬵�ס׷��
 */
public class BlockEnemy implements IStrategy {

	public void operate() {
		System.out.println("����˶Ϻ󣬵�ס׷��");
	}

}
