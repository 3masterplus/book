package com.company.section5;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
interface Calculator {

	public int exec(int a,int b);
	
}
