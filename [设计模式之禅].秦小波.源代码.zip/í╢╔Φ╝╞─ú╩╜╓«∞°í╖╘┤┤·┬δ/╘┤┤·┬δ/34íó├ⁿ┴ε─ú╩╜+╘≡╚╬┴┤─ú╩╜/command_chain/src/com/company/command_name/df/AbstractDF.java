package com.company.command_name.df;

import com.company.CommandVO;
import com.company.command_name.CommandName;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public abstract class AbstractDF extends CommandName {
	//Ĭ�ϲ���
	public final static String DEFAULT_PARAM = "";
	//����k
	public final static String K_PARAM = "k";
	//����g
	public final static String G_PARAM = "g";

}
