package com.company.command_name.ls;

import com.company.command_name.CommandName;



/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * �䵱Handler
 */
public abstract class AbstractLS extends CommandName{
	//Ĭ�ϲ���
	public final static String DEFAULT_PARAM = "";
	//����a
	public final static String A_PARAM ="a";
	//����l
	public final static String L_PARAM = "l";
	
	
	
}
