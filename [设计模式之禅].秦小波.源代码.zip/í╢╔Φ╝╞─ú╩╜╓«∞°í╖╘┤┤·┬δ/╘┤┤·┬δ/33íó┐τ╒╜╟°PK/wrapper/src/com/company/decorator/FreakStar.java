package com.company.decorator;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public class FreakStar implements IStar {

	public void act() {
		System.out.println("�����У��ݼ���׾��");
	}

}
