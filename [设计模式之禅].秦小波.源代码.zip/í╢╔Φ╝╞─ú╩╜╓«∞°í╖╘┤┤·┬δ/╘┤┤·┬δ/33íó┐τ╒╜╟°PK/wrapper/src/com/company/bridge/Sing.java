package com.company.bridge;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public class Sing extends AbstractAction {

	@Override
	public void desc() {
		System.out.println("���������ĸ���");
	}

}
