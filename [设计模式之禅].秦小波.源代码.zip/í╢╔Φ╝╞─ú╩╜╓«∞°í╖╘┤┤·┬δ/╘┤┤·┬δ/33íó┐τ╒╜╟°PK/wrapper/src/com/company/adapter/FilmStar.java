package com.company.adapter;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * ��Ӱ����
 *  
 */
public class FilmStar implements IStar {

	public void act(String context) {
		System.out.println("������Ϸ��" + context);
	}

}
