package com.company.bridge;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public abstract class AbstractAction {
	
	//ÿ�����������
	public abstract void desc();
}
