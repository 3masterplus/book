package com.company.section1;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * �ͻ���ʼʹ�����ģ��
 */
public class Client {

	public static void main(String[] args) {
		//ţ�湫˾ҪH1�ͺŵĺ���
		HummerH1Model h1 = new HummerH1Model();
		
		//H1ģ����ʾ
		h1.start();
		h1.engineBoom();
		h1.run();
		h1.alarm();
		h1.run(); 
		h1.stop();

	}

}
