package com.company.section3;

import java.util.Map;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public interface IOuterUserOfficeInfo {
	//����������Ϣ
	public Map getUserOfficeInfo();
}
