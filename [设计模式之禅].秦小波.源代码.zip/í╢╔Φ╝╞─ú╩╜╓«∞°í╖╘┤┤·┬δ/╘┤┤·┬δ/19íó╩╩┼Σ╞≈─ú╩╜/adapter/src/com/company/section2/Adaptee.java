package com.company.section2;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * Դ��ɫ
 */
public class Adaptee {
	
	//ԭ�е�ҵ���߼�
	public void doSomething(){
		System.out.println("I'm kind of busy,leave me alone,pls!");
	}
}
