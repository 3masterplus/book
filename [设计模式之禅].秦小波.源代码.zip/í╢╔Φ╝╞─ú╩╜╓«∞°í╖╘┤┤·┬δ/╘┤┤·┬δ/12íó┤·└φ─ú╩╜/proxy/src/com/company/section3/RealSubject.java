package com.company.section3;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public class RealSubject implements Subject {
	
	//ʵ�ַ���
	public void request() {
		//ҵ���߼�����
	}

}
