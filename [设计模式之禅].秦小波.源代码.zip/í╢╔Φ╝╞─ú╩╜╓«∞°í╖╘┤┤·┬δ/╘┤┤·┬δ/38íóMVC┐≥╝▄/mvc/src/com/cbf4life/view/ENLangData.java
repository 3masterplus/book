package com.cbf4life.view;

import java.util.Map;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public class ENLangData extends AbsLangData {

	
	@Override
	public Map<String, String> getItems() {
		/*
		 * Map�ṹΪ��
		 * key='title',value='title';
		 * key='menu', value='menu'
		 */
		return null;
	}

}
