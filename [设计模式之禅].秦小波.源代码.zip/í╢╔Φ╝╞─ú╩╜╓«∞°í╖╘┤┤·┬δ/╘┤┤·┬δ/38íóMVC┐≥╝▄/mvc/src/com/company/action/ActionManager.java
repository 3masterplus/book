package com.company.action;

import java.lang.reflect.Method;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public class ActionManager {
	

	//ִ��Action��ָ������
	public String execAction(String actionName){
		return null;
	}
}
