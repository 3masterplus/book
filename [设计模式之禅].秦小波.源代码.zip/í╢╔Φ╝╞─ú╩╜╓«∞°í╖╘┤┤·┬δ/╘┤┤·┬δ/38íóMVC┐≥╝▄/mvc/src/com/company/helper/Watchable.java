package com.company.helper;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public interface Watchable {

	//����
	public void watch();
}
