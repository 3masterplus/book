package com.company.section2;

import java.util.ArrayList;

import com.company.section1.User;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public interface IUserProvider {
	
	//�������������û�
	public ArrayList<User> findUser(boolean condition);
}
