package com.company.strategy;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 */
public interface Algorithm {

	//ѹ���㷨
	public boolean compress(String source,String to);

	//��ѹ���㷨
	public boolean uncompress(String source,String to);
}
