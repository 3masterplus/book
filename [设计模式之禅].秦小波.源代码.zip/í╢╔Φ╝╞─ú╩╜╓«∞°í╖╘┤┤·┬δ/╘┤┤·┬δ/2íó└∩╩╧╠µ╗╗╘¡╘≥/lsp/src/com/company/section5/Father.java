package com.company.section5;

import java.util.Collection;
import java.util.Map;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * ����
 */
@SuppressWarnings("all")
public class Father {
	
	public Collection doSomething(Map map){
		System.out.println("���౻ִ��...");		
		return map.values();
		
	}
}
