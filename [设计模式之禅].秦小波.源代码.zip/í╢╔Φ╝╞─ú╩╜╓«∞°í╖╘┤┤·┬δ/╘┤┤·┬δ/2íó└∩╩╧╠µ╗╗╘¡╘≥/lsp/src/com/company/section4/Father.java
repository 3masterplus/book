package com.company.section4;

import java.util.Collection;
import java.util.HashMap;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * ����
 */
@SuppressWarnings("all")
public class Father {
	
	public Collection doSomething(HashMap map){
		System.out.println("���౻ִ��...");		
		return map.values();
		
	}
}
