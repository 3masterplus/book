package com.company.section1;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * ��ǹ
 */
public class MachineGun extends AbstractGun{
	
	public void shoot(){
		System.out.println("��ǹɨ��...");
	}
}
